package com.geoffreypetain.voczilla.voczilla

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
